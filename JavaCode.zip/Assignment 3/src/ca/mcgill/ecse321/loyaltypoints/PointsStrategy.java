package ca.mcgill.ecse321.loyaltypoints;

public interface PointsStrategy {
	public int getPoints(double price);
}