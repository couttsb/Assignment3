package ca.mcgill.ecse321.loyaltypoints;

public class OperationThresholdPoints implements PointsStrategy{
	@Override
	public int getPoints(double price) {
		return (int) (price)*2;
	}
}