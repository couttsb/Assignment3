package ca.mcgill.ecse321.loyaltypoints;

public class OperationPerDollarPoints implements PointsStrategy{
	@Override
	public int getPoints(double price) {
		return (int) Math.floor(price);
	}
}